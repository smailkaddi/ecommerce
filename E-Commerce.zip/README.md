# site E-ecommerce "smayl.store

# Step 1. Download WordPress  
To install WordPress on localhost you need to download WordPress from the official website.wordpress.org Unzip the downloaded zip file.

# Step 2. Put WordPress in xamp’s htdocs

Now go to the xamp directory in your computer’s system drive. Open “htdocs” folder (found inside the xamp directory) and paste unpacked WordPress folder in 

# Step 3. Install WordPress on Localhost

Type localhost/wordpress (name of your WordPress file in the htdocs) on your browser’s address bar and hit enter. Now perform a few more actions to complete the WordPress installation on localhost. 


1  Select language and click “Continue“.

2 Click on “Let’s go!” button on the following page.

 Give all Required Information

3 This page requires “Database Name”. Username and Password both will be “root” as mentioned in the XAMP installation success page.

 “Submit” button at the bottom and click “Run the installation” on the very next page.

 You have successfully installed WordPress on your computer. Log into your locally hosted WordPress site now.

 ====> plugin 

 1-Wishlist
 2- woo ecommerce 
 3 -cart flows 
 4 - elementor
 5- wpf Forms

